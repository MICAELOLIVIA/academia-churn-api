# Sistema de Monitoramento de Academia com Previsão de Churn
### Visão Geral
API REST com painel web para gerenciar alunos de uma academia, registrar check-ins, gerar relatórios e prever possíveis desistências (churn) com base na frequência.

### Tecnologias utilizadas
- FastAPI
- PostgreSQL + SQLAlchemy
- RabbitMQ (para tarefas assíncronas)
- Jinja2 (templates web)
- JWT Auth (autenticação)
- Python Machine Learning (scikit-learn)

### Como rodar o projeto

1. Clone o projeto:
```bash
git clone https://github.com/seu-usuario/academia-churn-api.git
cd academia-churn-api
```

2. Ative o ambiente virtual:
```bash
python -m venv venv
venv\Scripts\activate
```

3. Instale as dependências:
```bash
pip install -r requirements.txt
```

4. Configure o banco (arquivo `.env`):
```env
DATABASE_URL=postgresql://postgres:senha@localhost:5432/academia
SECRET_KEY=sua_chave
ALGORITHM=HS256
```

5. Execute a aplicação:
```bash
uvicorn app.main:app --reload
```

6. Acesse no navegador:
```
http://localhost:8000
```

### Endpoints principais
- `POST /aluno/registro`: registra um novo aluno
- `POST /aluno/checkin`: registra entrada do aluno
- `GET /aluno/{id}/frequencia`: exibe frequência
- `GET /aluno/{id}/risco-churn`: previsão de desistência

### Modelo de IA
O modelo de churn considera:
- Frequência semanal
- Tempo desde o último check-in
- Duração média de visita
