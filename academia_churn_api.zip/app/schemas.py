from pydantic import BaseModel
from typing import Optional

class AlunoCreate(BaseModel):
    nome: str
    idade: int
    plano_id: int

class CheckinCreate(BaseModel):
    aluno_id: int
    data_checkin: str

class Frequencia(BaseModel):
    aluno_id: int
    frequencia_semana: int

class RiscoChurn(BaseModel):
    aluno_id: int
    probabilidade_churn: float
