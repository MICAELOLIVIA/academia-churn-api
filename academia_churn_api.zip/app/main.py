from fastapi import FastAPI
from app import models, crud, schemas, database

app = FastAPI()

@app.post("/aluno/registro")
async def registro_aluno(aluno: schemas.AlunoCreate):
    return crud.registrar_aluno(aluno)

@app.post("/aluno/checkin")
async def checkin_aluno(checkin: schemas.CheckinCreate):
    return crud.registrar_checkin(checkin)

@app.get("/aluno/{id}/frequencia")
async def frequencia_aluno(id: int):
    return crud.obter_frequencia(id)

@app.get("/aluno/{id}/risco-churn")
async def risco_churn(id: int):
    return crud.calcular_risco_churn(id)
